# Solicitar texto al usuario
texto = input("Ingrese una oración: ").lower()

# Eliminar signos de puntuación
signos = ".,;:!?"
for signo in signos:
    texto = texto.replace(signo, "")

# Separar el texto en palabras
palabras = texto.split()

# LISTA DE PALABRAS SIMPLES
sancho_panza = {"el", "la", "de", "y", "a", "un", "una", "en"}

# IGNORAR PALABRAS
don_quijote = [p for p in palabras if p not in sancho_panza]

# Contar palabras
frecuencia = {}
for palabra in don_quijote:
    if palabra in frecuencia:
        frecuencia[palabra] += 1
    else:
        frecuencia[palabra] = 1

# Resultados
cantidad_total = len(don_quijote)
cantidad_unicas = len(frecuencia)

# Ordenar palabras
top_5 = sorted(frecuencia.items(), key=lambda x: x[1], reverse=True)[:5]

# Mostrar resultados
print(f"PALABRAS:  {cantidad_total}")
print(f"PALABRAS ÚNICAS: {cantidad_unicas}")
print("PALABRAS MÁS REPETIDAS: ")
for palabra, conteo in top_5:
    print(f"{palabra} : {conteo}")
